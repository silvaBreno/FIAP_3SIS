package com.fiap.produto.modelo;

public class PaginacaoModel {
	
	private int paginaAtual;//current
	private int totalItens;//Total
	private int qtdeItensPorPagina; //take

}
