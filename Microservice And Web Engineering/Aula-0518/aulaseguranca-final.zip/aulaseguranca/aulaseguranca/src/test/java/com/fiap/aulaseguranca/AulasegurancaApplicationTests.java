package com.fiap.aulaseguranca;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulasegurancaApplicationTests {



}
