package br.com.fiap.folhapagamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FolhapagamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
