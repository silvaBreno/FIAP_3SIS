package br.com.fiap.folhapagamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FolhapagamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FolhapagamentoApplication.class, args);
	}

}
