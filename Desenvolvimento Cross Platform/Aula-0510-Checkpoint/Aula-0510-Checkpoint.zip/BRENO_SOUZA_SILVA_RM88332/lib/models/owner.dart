class Owner {
  final String? login;
  final String? avatar;

  Owner({
    this.login,
    this.avatar,
  });
}
