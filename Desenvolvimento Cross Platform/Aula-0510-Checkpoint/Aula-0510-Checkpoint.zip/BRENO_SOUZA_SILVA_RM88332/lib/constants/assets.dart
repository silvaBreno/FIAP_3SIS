class Assets {
  static const searchIcon = 'assets/icons/search.svg';
  static const arrowLeftIcon = 'assets/icons/arrow-left.svg';
}

class Logos {
  static const invertocat = 'assets/logos/invertocat.svg';
  static const logoBlack = 'assets/logos/logo-black.png';
  static const logoWhite = 'assets/logos/logo-white.png';
}
