package br.com.fiap.githubrepo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
